
```
Array
(
    [bucket] => media.smftampa.com
    [cacheControl] => public, max-age=36000, must-revalidate
    [componentCount] => 
    [contentDisposition] => 
    [contentEncoding] => 
    [contentLanguage] => 
    [contentType] => image/jpeg
    [crc32c] => Hrj+mg==
    [etag] => CMiK3caexMMCEAE=
    [generation] => 1422913686685000
    [id] => media.smftampa.com/2015/02/82db38c5ac911524bcf7be463fc04da73.jpg/1422913686685000
    [kind] => storage#object
    [md5Hash] => upblDqBJPhkDaDxe/9tQMQ==
    [mediaLink] => https://www.googleapis.com/download/storage/v1/b/media.smftampa.com/o/2015%2F02%2F82db38c5ac911524bcf7be463fc04da73.jpg?generation=1422913686685000&alt=media
    [metadata] => Array
        (
            [width] => 640
            [height] => 480
            [object-id] => 605
            [source-id] => 75ec2a48bd43df428a094ec1c10e7f71
            [file-hash] => b44df4fa79d667a3facac283d729dacb
        )
    [metageneration] => 1
    [name] => 2015/02/82db38c5ac911524bcf7be463fc04da73.jpg
    [selfLink] => https://www.googleapis.com/storage/v1/b/media.smftampa.com/o/2015%2F02%2F82db38c5ac911524bcf7be463fc04da73.jpg
    [size] => 50617
    [storageClass] => STANDARD
    [timeDeleted] => 
    [updated] => 2015-02-02T21:48:06.684Z
)

```